from .divahisdb_semantic_segmentation import DivahisdbSemanticSegmentation

__all__ = ['DivahisdbSemanticSegmentation']
