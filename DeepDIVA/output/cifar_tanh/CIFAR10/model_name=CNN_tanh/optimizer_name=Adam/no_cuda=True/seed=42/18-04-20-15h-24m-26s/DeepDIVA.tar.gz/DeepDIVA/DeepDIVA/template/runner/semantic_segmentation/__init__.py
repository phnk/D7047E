from .semantic_segmentation import SemanticSegmentation

__all__ = ['SemanticSegmentation']
